package com.strakher.mod.init;

import com.strakher.mod.StrakherMod;
import com.strakher.mod.entity.StrakherEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, StrakherMod.MOD_ID);

    public static final RegistryObject<EntityType<StrakherEntity>> STRAKHER =
            ENTITIES.register("strakher",
                    () -> EntityType.Builder.<StrakherEntity>of(StrakherEntity::new, MobCategory.MONSTER)
                            .sized(0.9f, 2.8f)
                            .clientTrackingRange(128)
                            .updateInterval(1)
                            .build(new ResourceLocation(StrakherMod.MOD_ID, "strakher").toString()));
}
