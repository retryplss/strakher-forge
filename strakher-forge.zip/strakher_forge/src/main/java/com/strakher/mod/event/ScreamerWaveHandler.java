package com.strakher.mod.event;

import com.strakher.mod.StrakherMod;
import com.strakher.mod.entity.StrakherEntity;
import com.strakher.mod.init.ModSounds;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ScreamerWaveHandler {

    private static class PlayerWaveState {
        int phase = 0;
        int timer = 0;
        int cycleCount = 0;
        int silenceDuration;

        PlayerWaveState() {
            // Первый раз — долгая тишина 12–20 минут
            silenceDuration = 14400 + (int)(Math.random() * 9600);
        }
    }

    private final Map<UUID, PlayerWaveState> states = new HashMap<>();

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        for (ServerLevel level : event.getServer().getAllLevels()) {
            for (ServerPlayer player : level.players()) {
                tick(player, level);
            }
        }
    }

    private void tick(ServerPlayer player, ServerLevel level) {
        PlayerWaveState s = states.computeIfAbsent(player.getUUID(), k -> new PlayerWaveState());

        boolean isNight = !level.isDay();
        boolean strakherNear = !level.getEntitiesOfClass(
                StrakherEntity.class,
                player.getBoundingBox().inflate(30.0)
        ).isEmpty();

        s.timer++;

        switch (s.phase) {

            // ФАЗА 0 — ТИШИНА
            case 0 -> {
                int threshold = s.silenceDuration;
                if (isNight) threshold = (int)(threshold * 0.6);
                if (strakherNear) threshold = (int)(threshold * 0.4);
                if (s.timer >= threshold) { s.phase = 1; s.timer = 0; }
            }

            // ФАЗА 1 — ШЁПОТ
            case 1 -> {
                if (s.timer == 1) {
                    level.playSound(null, player.getX(), player.getY(), player.getZ(),
                            ModSounds.HORROR_WHISPER.get(), SoundSource.MASTER,
                            0.4f + s.cycleCount * 0.05f, 0.9f);
                    player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 60, 0, false, false));
                }
                int dur = strakherNear ? 150 : 300 + (int)(Math.random() * 300);
                if (s.timer >= dur) { s.phase = 2; s.timer = 0; }
            }

            // ФАЗА 2 — НАРАСТАНИЕ
            case 2 -> {
                if (s.timer == 1) {
                    level.playSound(null, player.getX(), player.getY(), player.getZ(),
                            ModSounds.SCREAMER_WAVE_1.get(), SoundSource.MASTER,
                            0.6f + s.cycleCount * 0.08f, 1.0f);
                    player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0, false, false));
                }
                if (s.timer == 80) {
                    level.playSound(null, player.getX(), player.getY(), player.getZ(),
                            ModSounds.SCREAMER_WAVE_2.get(), SoundSource.MASTER,
                            0.8f + s.cycleCount * 0.08f, 0.95f);
                    player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 120, 1, false, false));
                    player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 0, false, false));
                }
                if (s.timer == 160) {
                    level.playSound(null, player.getX(), player.getY(), player.getZ(),
                            ModSounds.SCREAMER_WAVE_3.get(), SoundSource.MASTER,
                            1.0f + Math.min(s.cycleCount * 0.1f, 0.5f), 0.9f);
                    player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 160, 1, false, false));
                    player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0, false, false));
                }
                if (s.timer >= (strakherNear ? 160 : 220)) { s.phase = 3; s.timer = 0; }
            }

            // ФАЗА 3 — ПИК СКРИМЕР
            case 3 -> {
                if (s.timer == 1) {
                    float vol = Math.min(1.5f + s.cycleCount * 0.15f, 3.0f);
                    level.playSound(null, player.getX(), player.getY(), player.getZ(),
                            ModSounds.SCREAMER_FINAL.get(), SoundSource.MASTER, vol, 1.0f);
                    player.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 100, 2, false, false));
                    player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 2, false, false));
                    player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 2, false, false));
                    if (strakherNear) player.hurt(level.damageSources().magic(), 4.0f);
                    StrakherMod.LOGGER.info("[STRAKHER] СКРИМЕР! Игрок: {} Цикл #{}", player.getName().getString(), s.cycleCount + 1);
                }
                if (s.timer >= 40) {
                    s.phase = 0;
                    s.timer = 0;
                    s.cycleCount++;
                    s.silenceDuration = Math.max(6000, 14400 - s.cycleCount * 1200 + (int)(Math.random() * 4800));
                }
            }
        }
    }
}
