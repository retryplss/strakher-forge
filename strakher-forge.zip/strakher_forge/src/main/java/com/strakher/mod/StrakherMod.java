package com.strakher.mod;

import com.strakher.mod.entity.StrakherEntity;
import com.strakher.mod.event.ScreamerWaveHandler;
import com.strakher.mod.init.ModEntities;
import com.strakher.mod.init.ModItems;
import com.strakher.mod.init.ModSounds;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(StrakherMod.MOD_ID)
public class StrakherMod {

    public static final String MOD_ID = "strakher";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    public StrakherMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();

        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModSounds.SOUNDS.register(bus);

        bus.addListener(this::onAttributeCreate);

        MinecraftForge.EVENT_BUS.register(new ScreamerWaveHandler());

        LOGGER.info("[STRAKHER] Он уже наблюдает за тобой...");
    }

    private void onAttributeCreate(EntityAttributeCreationEvent event) {
        event.put(ModEntities.STRAKHER.get(), StrakherEntity.createAttributes().build());
    }
}
