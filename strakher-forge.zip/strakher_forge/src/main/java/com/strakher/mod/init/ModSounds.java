package com.strakher.mod.init;

import com.strakher.mod.StrakherMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, StrakherMod.MOD_ID);

    public static final RegistryObject<SoundEvent> STRAKHER_AMBIENT  = reg("strakher_ambient");
    public static final RegistryObject<SoundEvent> STRAKHER_HURT     = reg("strakher_hurt");
    public static final RegistryObject<SoundEvent> STRAKHER_DEATH    = reg("strakher_death");
    public static final RegistryObject<SoundEvent> STRAKHER_STEPS    = reg("strakher_steps");

    public static final RegistryObject<SoundEvent> SCREAMER_WAVE_1   = reg("screamer_wave_1");
    public static final RegistryObject<SoundEvent> SCREAMER_WAVE_2   = reg("screamer_wave_2");
    public static final RegistryObject<SoundEvent> SCREAMER_WAVE_3   = reg("screamer_wave_3");
    public static final RegistryObject<SoundEvent> SCREAMER_FINAL    = reg("screamer_final");

    public static final RegistryObject<SoundEvent> HORROR_AMBIENT_LOW = reg("horror_ambient_low");
    public static final RegistryObject<SoundEvent> HORROR_WHISPER     = reg("horror_whisper");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () ->
                SoundEvent.createVariableRangeEvent(new ResourceLocation(StrakherMod.MOD_ID, name)));
    }
}
