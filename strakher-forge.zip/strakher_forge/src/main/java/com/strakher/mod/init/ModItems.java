package com.strakher.mod.init;

import com.strakher.mod.StrakherMod;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, StrakherMod.MOD_ID);

    public static final RegistryObject<Item> STRAKHER_MARK = ITEMS.register("strakher_mark",
            () -> new Item(new Item.Properties().stacksTo(16)));
}
