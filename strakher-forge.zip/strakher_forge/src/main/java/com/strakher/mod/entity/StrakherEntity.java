package com.strakher.mod.entity;

import com.strakher.mod.init.ModItems;
import com.strakher.mod.init.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public class StrakherEntity extends Monster {

    private static final EntityDataAccessor<Boolean> PLAYER_WATCHING =
            SynchedEntityData.defineId(StrakherEntity.class, EntityDataSerializers.BOOLEAN);

    private int ironTrailTimer = 0;
    private int whisperTimer = 0;
    boolean beingWatched = false;

    public StrakherEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.noCulling = true;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(PLAYER_WATCHING, false);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new StrakherApproachGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, false));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 12.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 120.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.22D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.FOLLOW_RANGE, 80.0D)
                .add(Attributes.ARMOR, 6.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.8D)
                .add(Attributes.ATTACK_KNOCKBACK, 2.0D);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide()) {
            checkIfBeingWatched();

            if (beingWatched) {
                this.setNoAi(true);
                this.setDeltaMovement(Vec3.ZERO);
            } else {
                this.setNoAi(false);
            }

            ironTrailTimer++;
            if (ironTrailTimer >= 60) {
                ironTrailTimer = 0;
                if (this.random.nextFloat() < 0.30f) leaveIronTrail();
            }

            whisperTimer++;
            if (whisperTimer >= 140) {
                whisperTimer = 0;
                Player nearest = this.level().getNearestPlayer(this, 25.0);
                if (nearest != null) {
                    this.level().playSound(null,
                            nearest.getX(), nearest.getY(), nearest.getZ(),
                            ModSounds.HORROR_WHISPER.get(), SoundSource.HOSTILE,
                            0.6f, 0.85f + this.random.nextFloat() * 0.3f);
                    if (nearest.distanceTo(this) < 15.0) {
                        nearest.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 0, false, false));
                    }
                }
            }
        }
    }

    private void checkIfBeingWatched() {
        beingWatched = false;
        for (Player player : this.level().players()) {
            if (player.distanceTo(this) > 50.0) continue;
            Vec3 toMob = new Vec3(
                    this.getX() - player.getX(),
                    this.getEyeY() - player.getEyeY(),
                    this.getZ() - player.getZ()).normalize();
            double dot = player.getLookAngle().dot(toMob);
            if (dot > 0.965) { beingWatched = true; break; }
        }
        this.entityData.set(PLAYER_WATCHING, beingWatched);
    }

    private void leaveIronTrail() {
        BlockPos feet = this.blockPosition();
        Level level = this.level();
        if (level.isEmptyBlock(feet)) {
            if (this.random.nextFloat() < 0.15f)
                level.setBlock(feet, Blocks.IRON_BLOCK.defaultBlockState(), 3);
            else
                level.setBlock(feet, Blocks.IRON_ORE.defaultBlockState(), 3);
        }
    }

    @Override
    protected SoundEvent getAmbientSound() { return ModSounds.STRAKHER_AMBIENT.get(); }

    @Override
    protected SoundEvent getHurtSound(DamageSource ds) { return ModSounds.STRAKHER_HURT.get(); }

    @Override
    protected SoundEvent getDeathSound() { return ModSounds.STRAKHER_DEATH.get(); }

    @Override
    protected SoundEvent getStepSound(BlockPos pos, BlockState bs) {
        return ModSounds.STRAKHER_STEPS.get();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("IronTrailTimer", ironTrailTimer);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        ironTrailTimer = tag.getInt("IronTrailTimer");
    }

    @Override
    protected boolean isSunBurnTick() { return false; }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean wasRecentlyHit) {
        int iron = 3 + this.random.nextInt(4) + looting;
        this.spawnAtLocation(new ItemStack(Items.IRON_INGOT, iron));
        if (this.random.nextFloat() < 0.25f + looting * 0.05f)
            this.spawnAtLocation(new ItemStack(ModItems.STRAKHER_MARK.get(), 1));
    }

    static class StrakherApproachGoal extends Goal {
        private final StrakherEntity mob;
        private Player target;

        public StrakherApproachGoal(StrakherEntity mob) { this.mob = mob; }

        @Override
        public boolean canUse() {
            this.target = mob.level().getNearestPlayer(mob, 80.0);
            return target != null && !mob.beingWatched;
        }

        @Override
        public boolean canContinueToUse() {
            return target != null && target.isAlive() && !mob.beingWatched;
        }

        @Override
        public void tick() {
            if (target == null) return;
            double dist = mob.distanceTo(target);
            if (dist > 6.0) mob.getNavigation().moveTo(target, 0.85);
            else { mob.doHurtTarget(target); mob.getNavigation().stop(); }
            mob.getLookControl().setLookAt(target, 30, 30);
        }
    }
}
